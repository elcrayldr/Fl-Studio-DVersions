import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from synthetic import build_flp
from cray_flp_analyzer.compatibility import audit_downgrade, convert_downgrade_bytes

class TestCompatibilityEngine(unittest.TestCase):
    def test_audit_fails_closed_without_rules(self):
        data = build_flp(version="21.0.0.1")
        audit = audit_downgrade(data, 20)
        self.assertEqual(audit.status, "BLOCKED_NO_VALIDATED_RULES")
        self.assertEqual(audit.applicable_rule_count, 0)
        self.assertTrue(any("No hay reglas" in b for b in audit.blockers))

    def test_does_not_generate_fake_conversion(self):
        with self.assertRaisesRegex(ValueError, "bloqueada de forma segura"):
            convert_downgrade_bytes(build_flp(version="21.0.0.1"), 20)

    def test_refuses_malformed_file(self):
        with self.assertRaises(ValueError):
            audit_downgrade(b"not flp", 20)

    def test_target_must_be_known_profile(self):
        with self.assertRaises(ValueError):
            audit_downgrade(build_flp(version="21.0.0.1"), 13)

    def test_applies_only_explicit_validated_rule(self):
        data = build_flp(version="21.0.0.1", unknown=[(250, b"xyz")])
        manifest = {"schema_version":1,"policy":"fail_closed","targets":{"20":{"target_major":20,"status":"validated","rules":[{"id":"test-rule","source_major_min":21,"source_major_max":21,"target_major":20,"action":"drop_event_id","event_id":250,"status":"validated","evidence":"test fixture verified by test","fixture_sha256":"abc123","notes":"synthetic test event only"}]}}}
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"rules.json"; path.write_text(json.dumps(manifest), encoding="utf-8")
            out=convert_downgrade_bytes(data, 20, path)
        self.assertEqual(out.target_version, "20.0.0")
        self.assertIn("Eliminado evento ID 250", " ".join(out.changes))
        self.assertEqual(out.validation, "STRUCTURAL_ONLY")

if __name__ == "__main__": unittest.main()
