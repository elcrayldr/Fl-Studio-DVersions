# Fase 3 — prueba experimental de downgrade

## Qué se añadió

Se incorporó el comando `downgrade-experimental`, que genera una copia nueva de un FLP estructuralmente legible y cambia únicamente el texto de versión del evento 199. Incluye validación posterior, hash del original, registro de operaciones y reporte de los niveles A/B/C.

Ejemplo:

```powershell
$env:PYTHONPATH = "src"
python -m cray_flp_analyzer downgrade-experimental "C:\\proyectos\\tema.flp" --target-version 20.0.0.0 --out "C:\\proyectos\\convertidos"
```

## Limitaciones críticas

- Esto **no es todavía una conversión semántica real**. No se ha implementado la tabla de eventos incompatibles por versión, ni la transformación de plugins, automatizaciones o formatos de playlist.
- El destino solo cambia metadatos de versión. El proyecto puede no abrirse o puede abrirse con pérdida/comportamiento incorrecto.
- La lista de destinos experimentales (7, 8, 9, 11, 12, 20, 21, 24, 25, 26) refleja objetivos de investigación, no compatibilidad demostrada.
- La validación estructural A y la comparación de datos B no sustituyen la apertura real en FL Studio (nivel C), que queda `PENDIENTE`.
- No se han probado proyectos reales en esta fase; las pruebas nuevas usan FLP sintéticos.

## Próximo trabajo necesario para un conversor real

1. Corpus propio de FLP reales, etiquetado con versión exacta y hash.
2. Reglas versionadas basadas en estructura observada y documentación fiable; no eliminar IDs solo por ser desconocidos.
3. Comparar antes/después en eventos, patrones, notas, playlist, mixer, automatización y plugins.
4. Abrir los resultados en instalaciones de destino y probar reproducción/renderizado.
5. Solo entonces marcar rutas concretas como `verificadas`.
