"""Versión de la aplicación (fuente única)."""
APP_NAME = "Cray FLP Analyzer"
APP_NAME_UPPER = "CRAY FLP ANALYZER"
APP_VERSION = "0.3.0"
APP_STAGE = "candidata de entrega"  # analizador funcional; conversión FLP real aún no validada
BRAND = "Cray LDR — La Zeta Music"
