"""Serialización de eventos. Los eventos no modificados conservan sus bytes originales."""
from __future__ import annotations

import struct

from .constants import DATA_MAGIC
from .model import Event, FlpDocument


def encode_varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def build_event(eid: int, payload: bytes) -> bytes:
    if eid < 64:
        expected = 1
    elif eid < 128:
        expected = 2
    elif eid < 192:
        expected = 4
    else:
        return bytes([eid]) + encode_varint(len(payload)) + payload
    if len(payload) != expected:
        raise ValueError(f"El evento {eid} requiere {expected} bytes de datos, no {len(payload)}.")
    return bytes([eid]) + payload


def replaced_event(ev: Event, new_payload: bytes) -> Event:
    return Event(ev.index, ev.offset, ev.id, new_payload, build_event(ev.id, new_payload))


def serialize(doc: FlpDocument, events: list[Event] | None = None, keep_trailing: bool = False) -> bytes:
    """Reconstruye el archivo con el tamaño de datos recalculado a partir de los eventos."""
    evs = doc.events if events is None else events
    body = b"".join(e.raw for e in evs)
    out = doc.header_raw + DATA_MAGIC + struct.pack("<I", len(body)) + body
    if keep_trailing:
        out += doc.trailing
    return out
