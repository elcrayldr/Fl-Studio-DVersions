"""Lector tolerante del contenedor FLP. No lanza excepciones por datos malformados."""
from __future__ import annotations

import struct

from .constants import DATA_MAGIC, HEADER_MAGIC
from .model import Event, FlpDocument, StructIssue


def _issue(code: str, sev: str, offset: int | None = None, **params) -> StructIssue:
    return StructIssue(code, sev, offset, tuple(sorted(params.items())))


def read_varint(data: bytes, pos: int, end: int) -> tuple[int, int] | None:
    """Devuelve (valor, nuevo_pos) o None si es inválido/incompleto."""
    value = 0
    shift = 0
    for _ in range(5):
        if pos >= end:
            return None
        b = data[pos]
        pos += 1
        value |= (b & 0x7F) << shift
        if not b & 0x80:
            return value, pos
        shift += 7
    return None


def parse_flp(data: bytes) -> FlpDocument:
    doc = FlpDocument(file_size=len(data))
    n = len(data)
    if n == 0:
        doc.issues.append(_issue("EMPTY_FILE", "critical"))
        return doc
    if n < 14 and data[:4] != HEADER_MAGIC:
        doc.issues.append(_issue("TOO_SMALL", "critical", size=n))
        return doc
    if data[:4] != HEADER_MAGIC:
        doc.issues.append(_issue("BAD_MAGIC", "critical", 0))
        return doc

    doc.recognized = True
    if n < 8:
        doc.issues.append(_issue("HEADER_TRUNCATED", "critical", 4))
        return doc
    hsize = struct.unpack_from("<I", data, 4)[0]
    doc.header_size = hsize
    if hsize != 6:
        doc.issues.append(_issue("HEADER_SIZE_UNEXPECTED", "warning", 4, size=hsize))
    if hsize > 1024 or 8 + hsize > n:
        doc.issues.append(_issue("HEADER_TRUNCATED", "critical", 4))
        return doc
    doc.header_raw = data[: 8 + hsize]
    if hsize >= 6:
        doc.fmt, doc.n_channels, doc.ppq = struct.unpack_from("<hHH", data, 8)

    pos = 8 + hsize
    if data[pos:pos + 4] != DATA_MAGIC:
        doc.issues.append(_issue("DATA_CHUNK_MISSING", "critical", pos))
        return doc
    if pos + 8 > n:
        doc.issues.append(_issue("DATA_CHUNK_MISSING", "critical", pos))
        return doc
    declared = struct.unpack_from("<I", data, pos + 4)[0]
    doc.data_declared = declared
    start = pos + 8
    doc.data_start = start
    available = n - start
    if declared > available:
        doc.truncated = True
        end = n
        doc.issues.append(_issue("DATA_TRUNCATED", "error", start, declared=declared,
                                 available=available, missing=declared - available))
    else:
        end = start + declared
        if declared < available:
            doc.trailing = data[end:]
            doc.issues.append(_issue("TRAILING_DATA", "warning", end, n=len(doc.trailing)))

    p = start
    idx = 0
    while p < end:
        eid = data[p]
        q = p + 1
        if eid < 64:
            length = 1
        elif eid < 128:
            length = 2
        elif eid < 192:
            length = 4
        else:
            v = read_varint(data, q, end)
            if v is None:
                _incomplete(doc, data, p, end, "VARINT_INVALID" if end - q >= 5 else "EVENT_INCOMPLETE")
                break
            length, q = v
        if q + length > end:
            _incomplete(doc, data, p, end, "EVENT_INCOMPLETE")
            break
        doc.events.append(Event(idx, p, eid, data[q:q + length], data[p:q + length]))
        idx += 1
        p = q + length
    doc.parsed_end = p if not doc.tail else doc.tail_offset
    if not doc.events and not doc.tail:
        doc.issues.append(_issue("NO_EVENTS", "error", start))
    return doc


def _incomplete(doc: FlpDocument, data: bytes, p: int, end: int, code: str) -> None:
    doc.tail = data[p:end]
    doc.tail_offset = p
    if doc.truncated:
        doc.issues.append(_issue("EVENT_INCOMPLETE", "error", p, at=p, n=end - p))
    elif code == "VARINT_INVALID":
        doc.issues.append(_issue("VARINT_INVALID", "error", p, at=p))
    else:
        doc.issues.append(_issue("EVENT_OVERRUN", "error", p, at=p))
