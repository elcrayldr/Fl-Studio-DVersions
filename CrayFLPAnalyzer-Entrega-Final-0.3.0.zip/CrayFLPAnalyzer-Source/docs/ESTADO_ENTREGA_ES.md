# Estado de entrega — 0.3.0

## Verificado en este entorno
- Suite automatizada: 35 pruebas aprobadas.
- Compilación sintáctica de módulos Python.
- CLI ejecutable desde el código fuente.
- Auditoría bloquea conversiones si no hay reglas validadas.
- El empaquetado incluye explícitamente el manifiesto JSON de reglas, necesario al distribuir la aplicación.

## No verificado aquí
- Ejecutable de Windows producido por PyInstaller.
- Instalador de Inno Setup.
- GUI en Windows 10/11.
- Apertura o reproducción de proyectos en FL Studio real.

## No afirmar
No llamar a este paquete conversor completo. El modo `downgrade-experimental` solo cambia metadatos de versión. Las reglas de conversión por destinos siguen pendientes de evidencia real.
