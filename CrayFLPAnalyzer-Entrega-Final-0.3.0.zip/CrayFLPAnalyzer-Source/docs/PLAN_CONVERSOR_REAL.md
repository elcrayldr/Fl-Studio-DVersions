# Plan técnico: conversor real entre versiones de FL Studio

Estado a 2026-10-27: **no implementado**. Esta aplicación es por ahora un analizador y reparador estructural conservador. No debe presentarse como conversor hasta que existan pruebas con archivos reales y FL Studio de destino.

## Límite técnico importante

Image-Line indica que los proyectos guardados en una versión más nueva pueden no abrir correctamente en versiones antiguas, porque cambian datos y funciones entre versiones. Por tanto, no existe una conversión universal fiable que se consiga cambiando el número de versión del archivo. Una conversión descendente real exige comprender y transformar las estructuras y funciones incompatibles, y algunas no tienen equivalente en versiones antiguas.

Referencia oficial: https://support.image-line.com/action/knowledgebase?ans=515
Referencia oficial: https://support.image-line.com/action/knowledgebase?ans=591&id=78

## Estrategia segura por fases

1. **Corpus de pruebas real:** recopilar proyectos de prueba propios y legales, guardados por distintas versiones de FL Studio, sin distribuir contenido de terceros. Registrar versión exacta y hash SHA-256.
2. **Lector versionado:** analizar el contenedor y conservar eventos desconocidos sin reinterpretarlos. Toda interpretación semántica debe marcar su nivel de confianza.
3. **Matriz de compatibilidad:** identificar eventos y estados introducidos por versión; no inferir que un proyecto es convertible solo por su versión de cabecera.
4. **Transformaciones específicas:** añadir reglas por versión únicamente cuando se conozcan el significado, los valores predeterminados y el comportamiento de degradación. Cada regla debe declarar qué información puede perderse.
5. **Salida segura:** crear siempre una copia con nombre nuevo, mantener el original intacto y emitir un informe de cambios y pérdida potencial.
6. **Validación externa:** abrir la copia en la versión de destino y comprobar canales, patrones, playlist, automatizaciones, mixer, plugins y samples; comparar renderizado cuando sea posible. Sin esta comprobación, el resultado no se marca como conversión validada.
7. **Instalador:** compilar el EXE y el instalador en Windows 10/11 x64, probar instalación, ejecución, permisos de usuario y desinstalación.

## Qué puede entregarse honestamente ahora

- Analizador de estructura FLP y reporte de diagnóstico.
- Reparaciones limitadas de estructura y rutas, siempre sobre una copia.
- Evaluación preliminar de compatibilidad, sin afirmar que convierte.
- Compilación del analizador actual mediante `build_windows.bat` en un equipo Windows con Python e Inno Setup instalados.

## Criterio de aceptación para llamar a algo “conversor”

No basta con que el archivo resultante tenga una cabecera válida. Debe abrirse en la versión objetivo, conservar los elementos que se declaren compatibles y documentar las pérdidas inevitables. Las pruebas sintéticas incluidas en el repositorio solo prueban el parser; no prueban conversión de proyectos reales.
