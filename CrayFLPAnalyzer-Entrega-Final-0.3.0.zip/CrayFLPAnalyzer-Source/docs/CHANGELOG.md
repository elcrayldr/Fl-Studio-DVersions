# Registro de cambios
## 0.2.0 (alfa) — reescritura del prototipo 0.1.0
- Arquitectura modular en `src/cray_flp_analyzer` (lector FLP, diagnóstico, reparación, conversión/evaluación, rutas, plugins, validación, informes, configuración, GUI, CLI).
- Lector estructurado de FLhd/FLdt con tolerancia a truncados y reserialización exacta.
- Protección del original, reparación sobre copia, validación A/B, nivel C pendiente.
- Scripts de PyInstaller e Inno Setup (sin compilar en este entorno).
## 0.1.0 — prototipo de solo lectura (en `prototype_v0_1/`)


## Revisión de desarrollo (2026-10-27)
- Se aclara en la interfaz que la conversión real entre versiones aún no está implementada.
- El botón pasa a llamarse «Evaluar conversión» y avisa cuando no se genera ningún archivo.
- Se añade un plan técnico para desarrollar y validar conversiones reales por versión.
- El script de compilación devuelve error si falta Inno Setup, para evitar confundir el portable con un instalador terminado.

## Fase 3 (2026-10-27)
- Añadida prueba experimental `downgrade-experimental`: cambia el evento de versión 199 y escribe una copia nueva.
- Validación estructural previa/posterior y registro de hashes; se niega a procesar archivos dañados o versiones no reconocidas.
- Aviso explícito de que todavía no elimina ni transforma eventos incompatibles; apertura real queda pendiente.
- Pruebas automatizadas ampliadas de 27 a 30; todas pasan con FLP sintéticos.
