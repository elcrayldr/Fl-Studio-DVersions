from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class StructIssue:
    code: str
    severity: str            # critical | error | warning | info
    offset: int | None = None
    params: tuple = ()       # pares (clave, valor) para el mensaje

    def p(self) -> dict:
        return dict(self.params)


@dataclass
class Event:
    index: int
    offset: int
    id: int
    payload: bytes
    raw: bytes               # bytes exactos del archivo (id + longitud + payload)

    @property
    def size_class(self) -> str:
        if self.id < 64:
            return "byte"
        if self.id < 128:
            return "word"
        if self.id < 192:
            return "dword"
        return "var"


@dataclass
class FlpDocument:
    file_size: int
    recognized: bool = False         # firma FLhd presente
    header_raw: bytes = b""          # 'FLhd' + tamaño + cuerpo
    header_size: int | None = None
    fmt: int | None = None
    n_channels: int | None = None
    ppq: int | None = None
    data_declared: int | None = None
    data_start: int | None = None
    events: list[Event] = field(default_factory=list)
    parsed_end: int | None = None    # offset absoluto tras el último evento completo
    tail: bytes = b""                # bytes de un evento incompleto al final
    tail_offset: int | None = None
    trailing: bytes = b""            # bytes tras el final declarado del bloque
    truncated: bool = False
    issues: list[StructIssue] = field(default_factory=list)

    @property
    def structurally_ok(self) -> bool:
        return self.recognized and not any(i.severity in ("critical", "error") for i in self.issues)

    def has(self, code: str) -> bool:
        return any(i.code == code for i in self.issues)
