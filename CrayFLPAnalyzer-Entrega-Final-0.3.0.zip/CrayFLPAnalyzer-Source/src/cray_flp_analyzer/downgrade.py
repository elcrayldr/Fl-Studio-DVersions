"""Prueba experimental de downgrade FLP.

Esta función SOLO cambia el evento de metadatos de versión (ID 199). No elimina
ni transforma eventos incompatibles y, por tanto, NO constituye una conversión
semántica ni garantiza que el proyecto abra en FL Studio antiguo. Se ofrece como
herramienta de investigación explícita, con salida nueva y validación estructural.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .flp import parse_flp, serialize
from .flp.model import Event
from .flp.semantics import interpret
from .flp.writer import replaced_event
from .session import OperationResult, run_safe_operation
from .validate import ValidationReport, validate_pair

# Destinos anunciados públicamente por la herramienta de referencia. La lista
# es de destinos de prueba, no una afirmación de compatibilidad verificada.
EXPERIMENTAL_TARGETS = (7, 8, 9, 11, 12, 20, 21, 24, 25, 26)


@dataclass
class DowngradeResult:
    operation: OperationResult
    validation: ValidationReport
    source_version: str
    target_version: str
    limitations: list[str]


def _version_payload(event: Event, target_version: str) -> Event:
    # El evento FL version es ASCII incluso en proyectos que guardan otros
    # textos como UTF-16LE. Conservamos el terminador nulo si existía.
    old = event.payload
    new = target_version.encode("ascii") + (b"\x00" if old.endswith(b"\x00") else b"")
    return replaced_event(event, new)


def experimental_patch_bytes(data: bytes, target_version: str) -> tuple[bytes, list[str], str]:
    """Crea un FLP con metadatos de versión modificados; nunca afirma compatibilidad."""
    parts = target_version.split(".")
    if not parts or any(not p.isdigit() for p in parts) or len(parts) > 4:
        raise ValueError("La versión destino debe tener formato como 12.0.0 o 20.0.0.0.")
    target_major = int(parts[0])
    if target_major not in EXPERIMENTAL_TARGETS:
        raise ValueError(f"Destino no incluido en los perfiles experimentales: {target_major}.")
    doc = parse_flp(data)
    if not doc.recognized or not doc.structurally_ok or doc.truncated or doc.tail:
        raise ValueError("El archivo no supera la validación estructural; no se genera salida.")
    info = interpret(doc)
    if not info.version or not info.version_text:
        raise ValueError("No se ha podido detectar con seguridad la versión de origen.")
    if info.version[0] <= target_major:
        raise ValueError("La versión de origen no parece más nueva que el destino; no se aplica downgrade.")
    matches = [e for e in doc.events if e.id == 199]
    if len(matches) != 1:
        raise ValueError(f"Se esperaba un único evento de versión (ID 199); encontrados: {len(matches)}.")
    changed = [_version_payload(e, target_version) if e.id == 199 else e for e in doc.events]
    out = serialize(doc, changed, keep_trailing=False)
    check = parse_flp(out)
    after = interpret(check)
    if not check.structurally_ok or after.version_text != target_version:
        raise ValueError("La salida no supera la comprobación estructural posterior; se cancela.")
    changes = [f"Metadatos de versión: {info.version_text} -> {target_version}.",
               "No se transformaron ni eliminaron eventos incompatibles.",
               "Resultado EXPERIMENTAL: no equivale a una conversión validada."]
    return out, changes, info.version_text


def downgrade_file_experimental(source: Path, output_dir: Path, target_version: str) -> DowngradeResult:
    source = Path(source)
    original = source.read_bytes()
    # Validamos antes de crear directorios/salidas.
    _out, _changes, source_version = experimental_patch_bytes(original, target_version)

    def transform(data: bytes) -> tuple[bytes, list[str]]:
        out, changes, _ = experimental_patch_bytes(data, target_version)
        return out, changes

    op = run_safe_operation(source, output_dir, "experimental_version_patch", "experimental_downgrade", transform)
    result_bytes = Path(op.output).read_bytes() if op.output else b""
    val = validate_pair(original, result_bytes)
    return DowngradeResult(op, val, source_version, target_version, [
        "Solo se modifica el texto de versión almacenado en el evento 199.",
        "No hay todavía una tabla verificada de eventos incompatibles por versión.",
        "El archivo puede seguir sin abrirse, abrirse con pérdida o comportarse incorrectamente.",
        "Conserva el original y prueba la copia en la versión de destino; no uses el resultado como único respaldo.",
        "Nivel C (apertura real en FL Studio): pendiente de prueba manual.",
    ])
