"""Motor de compatibilidad descendente basado en reglas explícitas y auditables.

No infiere incompatibilidad a partir de un ID desconocido. Las reglas destructivas
solo se activan cuando el perfil correspondiente contiene reglas marcadas como
validated, con evidencia y fixture SHA-256. El manifiesto incluido está vacío de
reglas destructivas porque aún no hay corpus de FL Studio real validado.
"""
from __future__ import annotations

import hashlib
import json
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .flp import parse_flp, serialize
from .flp.semantics import interpret
from .flp.writer import replaced_event

TARGETS = (7, 8, 9, 11, 12, 20)
MANIFEST_NAME = "compatibility_rules.json"

@dataclass
class CompatibilityAudit:
    source_version: str | None
    target_major: int
    event_counts: dict[int, int]
    known_text_fields: dict[str, int]
    applicable_rule_count: int
    removable_event_count: int
    blockers: list[str]
    status: str

@dataclass
class ConversionOutput:
    data: bytes
    changes: list[str]
    source_version: str
    target_version: str
    validation: str = "STRUCTURAL_ONLY"


def default_manifest() -> dict[str, Any]:
    """Versioned targets; no fabricated event IDs or destructive rules."""
    return {
        "schema_version": 1,
        "policy": "fail_closed",
        "targets": {
            str(v): {
                "target_major": v,
                "status": "research_pending",
                "rules": [],
                "notes": "Sin reglas destructivas hasta validar IDs contra proyectos reales y FL Studio destino."
            } for v in TARGETS
        },
        "rule_schema": {
            "id": "stable-rule-id",
            "source_major_min": "integer",
            "source_major_max": "integer",
            "target_major": "integer",
            "action": "drop_event_id",
            "event_id": "integer 0..255",
            "status": "validated only",
            "evidence": "URL or lab record required",
            "fixture_sha256": "SHA-256 of source fixture required",
            "notes": "what is lost and why the target lacks this event"
        }
    }


def load_manifest(path: Path | None = None) -> dict[str, Any]:
    if path is None:
        path = Path(__file__).with_name(MANIFEST_NAME)
    if not path.exists():
        return default_manifest()
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema_version") != 1 or data.get("policy") != "fail_closed":
        raise ValueError("Manifiesto de compatibilidad desconocido o política insegura.")
    return data


def _validated_rules(manifest: dict[str, Any], source_major: int, target_major: int) -> list[dict[str, Any]]:
    target = manifest.get("targets", {}).get(str(target_major), {})
    rules = []
    for rule in target.get("rules", []):
        if rule.get("status") != "validated":
            continue
        if rule.get("action") != "drop_event_id":
            continue
        if rule.get("target_major") != target_major:
            continue
        if not (rule.get("source_major_min", 999) <= source_major <= rule.get("source_major_max", -1)):
            continue
        if not rule.get("evidence") or not rule.get("fixture_sha256") or not rule.get("notes"):
            continue
        event_id = rule.get("event_id")
        if isinstance(event_id, int) and 0 <= event_id <= 255:
            rules.append(rule)
    return rules


def audit_downgrade(data: bytes, target_major: int, manifest_path: Path | None = None) -> CompatibilityAudit:
    if target_major not in TARGETS:
        raise ValueError(f"Destino no soportado por el perfil: {target_major}. Destinos: {TARGETS}")
    doc = parse_flp(data)
    if not doc.recognized or not doc.structurally_ok or doc.truncated or doc.tail:
        raise ValueError("FLP no supera la validación estructural; no se puede evaluar la conversión.")
    info = interpret(doc)
    if not info.version:
        raise ValueError("No se pudo identificar la versión de origen con seguridad.")
    source_major = info.version[0]
    if source_major <= target_major:
        raise ValueError("El archivo no parece ser más nuevo que el destino seleccionado.")
    manifest = load_manifest(manifest_path)
    rules = _validated_rules(manifest, source_major, target_major)
    ids = {e.id for e in doc.events}
    applicable = [r for r in rules if r["event_id"] in ids]
    blockers = []
    target = manifest.get("targets", {}).get(str(target_major), {})
    if not target.get("rules"):
        blockers.append("No hay reglas de compatibilidad verificadas para este destino.")
    if not applicable:
        blockers.append("No se identificaron reglas validadas aplicables a los eventos de este proyecto.")
    blockers.append("No se ha validado la apertura del resultado en FL Studio real; el nivel C sigue pendiente.")
    # IDs sin interpretación semántica son señal para inspección, nunca se borran por conjetura.
    unknown = sorted(set(info.unknown_ids))
    if unknown:
        blockers.append("Hay IDs de evento no interpretados; no se eliminarán automáticamente: " + ", ".join(map(str, unknown[:30])))
    return CompatibilityAudit(
        source_version=info.version_text, target_major=target_major,
        event_counts=dict(sorted(info.event_counts.items())),
        known_text_fields={k: len(v) for k, v in info.texts.items()},
        applicable_rule_count=len(applicable), removable_event_count=sum(1 for e in doc.events if any(e.id == r["event_id"] for r in applicable)),
        blockers=blockers, status="READY_FOR_RULES" if applicable else "BLOCKED_NO_VALIDATED_RULES")


def convert_downgrade_bytes(data: bytes, target_major: int, manifest_path: Path | None = None) -> ConversionOutput:
    """Aplica exclusivamente reglas validadas; por defecto se niega a generar FLP.

    No reescribe el evento de versión a ciegas. Se necesita un perfil con al menos
    una regla aplicable y una política de destino validada para activar salida.
    """
    audit = audit_downgrade(data, target_major, manifest_path)
    if audit.status != "READY_FOR_RULES" or audit.removable_event_count == 0:
        raise ValueError("Conversión bloqueada de forma segura: no hay reglas validadas aplicables. " + " ".join(audit.blockers))
    doc = parse_flp(data)
    info = interpret(doc)
    manifest = load_manifest(manifest_path)
    rules = _validated_rules(manifest, info.version[0], target_major)
    ids_to_drop = {r["event_id"] for r in rules if any(e.id == r["event_id"] for e in doc.events)}
    # En esta fase solo se admite acción explícita de eliminación validada.
    events = [e for e in doc.events if e.id not in ids_to_drop]
    # No inventar el número de versión del formato interno: evento 199 es texto de versión del productor.
    version_events = [e for e in events if e.id == 199]
    if len(version_events) != 1:
        raise ValueError("La salida no puede reconstruir el evento de versión sin ambigüedad.")
    target_version = f"{target_major}.0.0"
    new_version_event = replaced_event(version_events[0], target_version.encode("ascii") + (b"\x00" if version_events[0].payload.endswith(b"\x00") else b""))
    events = [new_version_event if e.id == 199 else e for e in events]
    out = serialize(doc, events, keep_trailing=False)
    check = parse_flp(out)
    if not check.structurally_ok or check.truncated or check.tail or interpret(check).version_text != target_version:
        raise ValueError("La salida no supera las comprobaciones estructurales posteriores.")
    changes = [f"Versión declarada: {info.version_text} -> {target_version}."]
    for r in rules:
        if r["event_id"] in ids_to_drop:
            changes.append(f"Eliminado evento ID {r['event_id']} según regla {r['id']}: {r['notes']}")
    changes.append("Validación estructural solamente; apertura y sonido deben comprobarse en FL Studio destino.")
    return ConversionOutput(out, changes, info.version_text, target_version)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
