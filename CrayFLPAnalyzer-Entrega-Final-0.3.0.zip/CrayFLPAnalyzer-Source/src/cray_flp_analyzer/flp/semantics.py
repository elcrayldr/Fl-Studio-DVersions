"""Interpretación (con niveles de confianza) de los eventos de un FLP.

Todo lo que dependa del significado de un id de evento se marca 'inferred'.
Lo puramente estructural (cabecera, recuentos) se marca 'confirmed'.
"""
from __future__ import annotations

import re
import struct
from collections import Counter
from dataclasses import dataclass, field

from .constants import KNOWN_IDS, OTHER_KNOWN_EVENTS, TEXT_EVENTS, TEXT_UTF16_FROM_VERSION
from .model import Event, FlpDocument

_VERSION_RE = re.compile(r"^\d+(\.\d+){1,4}$")


@dataclass
class SampleRef:
    event_index: int
    path: str
    encoding: str


@dataclass
class PluginRef:
    event_index: int
    name: str
    source_id: int


@dataclass
class ProjectInfo:
    version_text: str | None = None
    version: tuple[int, ...] | None = None
    version_confidence: str = "unknown"
    text_encoding: str = "unknown"
    tempo: float | None = None
    tempo_confidence: str = "unknown"
    ppq: int | None = None
    channels_header: int | None = None
    title: str | None = None
    texts: dict[str, list[str]] = field(default_factory=dict)
    samples: list[SampleRef] = field(default_factory=list)
    plugins: list[PluginRef] = field(default_factory=list)
    event_counts: dict[int, int] = field(default_factory=dict)
    uninterpreted_events: int = 0
    total_events: int = 0
    unknown_ids: list[int] = field(default_factory=list)
    version_issue: str | None = None


def decode_ascii_text(payload: bytes) -> str:
    return payload.split(b"\x00", 1)[0].decode("ascii", errors="replace").strip()


def looks_utf16(payload: bytes) -> bool:
    if len(payload) < 4 or len(payload) % 2:
        return False
    zeros_odd = sum(1 for b in payload[1::2] if b == 0)
    return zeros_odd >= (len(payload) // 2) * 0.6


def decode_text(payload: bytes, utf16: bool) -> tuple[str, str]:
    if utf16:
        try:
            return payload.decode("utf-16le").rstrip("\x00"), "utf-16le"
        except UnicodeDecodeError:
            pass
    try:
        return payload.split(b"\x00", 1)[0].decode("cp1252"), "cp1252"
    except UnicodeDecodeError:
        return payload.split(b"\x00", 1)[0].decode("latin-1"), "latin-1"


def encode_text(text: str, encoding: str) -> bytes:
    if encoding == "utf-16le":
        return (text + "\x00").encode("utf-16le")
    return text.encode(encoding) + b"\x00"


def parse_version(text: str) -> tuple[int, ...] | None:
    if not _VERSION_RE.match(text):
        return None
    return tuple(int(x) for x in text.split("."))


def interpret(doc: FlpDocument) -> ProjectInfo:
    info = ProjectInfo(ppq=doc.ppq, channels_header=doc.n_channels, total_events=len(doc.events))
    counts = Counter(e.id for e in doc.events)
    info.event_counts = dict(sorted(counts.items()))
    info.unknown_ids = sorted(i for i in counts if i not in KNOWN_IDS)
    info.uninterpreted_events = sum(counts[i] for i in info.unknown_ids)

    # versión (siempre ASCII)
    for e in doc.events:
        if e.id == 199:
            txt = decode_ascii_text(e.payload)
            info.version_text = txt
            info.version = parse_version(txt)
            if info.version:
                info.version_confidence = "inferred"
            else:
                info.version_issue = txt
            break

    if info.version and info.version >= TEXT_UTF16_FROM_VERSION:
        utf16_default: bool | None = True
    elif info.version:
        utf16_default = False
    else:
        utf16_default = None

    def decode_event(e: Event) -> tuple[str, str]:
        use16 = utf16_default if utf16_default is not None else looks_utf16(e.payload)
        return decode_text(e.payload, bool(use16))

    for e in doc.events:
        key = TEXT_EVENTS.get(e.id)
        if key is None or key == "fl_version":
            continue
        text, enc = decode_event(e)
        info.text_encoding = enc
        info.texts.setdefault(key, []).append(text)
        if key == "sample_path":
            info.samples.append(SampleRef(e.index, text, enc))
        elif key in ("plugin_name", "default_plugin_name") and text:
            info.plugins.append(PluginRef(e.index, text, e.id))
    if info.texts.get("title"):
        info.title = info.texts["title"][0]

    # tempo
    for e in doc.events:
        if e.id == 156 and len(e.payload) == 4:
            info.tempo = struct.unpack("<I", e.payload)[0] / 1000.0
            info.tempo_confidence = "inferred"
            break
    if info.tempo is None:
        for e in doc.events:
            if e.id == 66 and len(e.payload) == 2:
                info.tempo = float(struct.unpack("<H", e.payload)[0])
                info.tempo_confidence = "inferred"
                break
    return info


def known_name(eid: int) -> str:
    return TEXT_EVENTS.get(eid) or OTHER_KNOWN_EVENTS.get(eid) or f"desconocido_{eid}"
