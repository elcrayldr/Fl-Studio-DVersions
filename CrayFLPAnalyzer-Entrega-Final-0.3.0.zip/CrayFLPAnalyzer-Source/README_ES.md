# Cray FLP Analyzer 0.3.0 — candidata de entrega

Aplicación de Windows para analizar archivos `.flp`, diagnosticar algunos problemas estructurales, comparar proyectos, reparar copias en casos limitados y generar informes.

## Importante: alcance real

**Esta versión no es todavía un conversor real entre versiones de FL Studio.** Incluye auditoría de compatibilidad y un modo experimental que cambia únicamente el texto de versión almacenado; ese modo NO transforma el proyecto y NO garantiza que abra en versiones antiguas. El motor de reglas se bloquea de forma segura mientras no existan reglas sustentadas por archivos reales y pruebas en FL Studio de destino.

No se ha validado con proyectos musicales reales ni con apertura/reproducción en FL Studio 7, 8, 9, 11, 12, 20, 21, 24, 25 o 26. Los ejemplos del paquete son sintéticos. Conserva siempre copias de seguridad.

## Ejecutar desde el código

Requisitos: Windows 10/11 de 64 bits, Python 3.11+ con Tcl/Tk.

```bat
python run_app.py
```

CLI de análisis: `python run_app.py analyze samples\synthetic\synthetic_valido.flp`

## Pruebas automatizadas

```bat
set PYTHONPATH=src
python -m unittest discover -s tests -v
```

## Crear el ejecutable y el instalador en Windows

1. Instala Python 3.11+ de 64 bits marcando **Add Python to PATH**.
2. Instala Inno Setup 6 desde su web oficial.
3. Extrae todo el ZIP en una carpeta local (no lo ejecutes dentro del ZIP).
4. Haz doble clic en `build_windows.bat`.
5. Si finaliza correctamente, revisa `release\CrayFLPAnalyzer-Portable.zip` y `release\CrayFLPAnalyzer-Setup.exe`.

El script ejecuta las pruebas antes de empaquetar. Si falla, no uses los artefactos parciales. El instalador se genera en Windows; no se ha podido compilar ni probar este instalador desde el entorno actual.

## Contenido

- `src/`: código de aplicación, lector FLP y auditoría de compatibilidad.
- `tests/`: pruebas automatizadas.
- `samples/synthetic/`: fixtures sintéticos, no proyectos de FL Studio reales.
- `docs/`: manual, limitaciones, informe y plan técnico.
- `build_windows.bat`, `CrayFLPAnalyzer.spec`, `installer/CrayFLPAnalyzer.iss`: empaquetado para Windows.

## Estado de la entrega

La entrega actual es una candidata de entrega del **analizador**, no la versión final del conversor solicitado. Para afirmar conversión real hacen falta proyectos de referencia, reglas de transformación verificadas y pruebas de apertura y reproducción en las versiones destino. No se inventan IDs de eventos ni se eliminan eventos desconocidos por conjetura.
