# Fase 4 — motor de reglas de compatibilidad

## Qué incorpora
- Registro de perfiles objetivo 7, 8, 9, 11, 12 y 20.
- Auditoría de versión, eventos y reglas aplicables sin alterar el archivo.
- Motor de transformaciones con política `fail_closed`: solo aplica acciones `drop_event_id` declaradas y marcadas `validated`, con evidencia, intervalo de origen y notas de pérdida.
- Pruebas sintéticas que comprueban tanto el bloqueo seguro como la ejecución de una regla de ejemplo aislada.
- Nuevo comando `audit-downgrade`.

## Límite importante
Los perfiles incluidos intencionalmente NO contienen reglas destructivas. No hay aquí un corpus de proyectos reales que permita afirmar qué IDs son exclusivos de FL Studio 21 frente a 20, o de 20 frente a 12/11/9/8/7. Por tanto, el motor se niega a generar una conversión por defecto. La regla de ID 250 en los tests es solo una fixture sintética para probar la infraestructura; no es una afirmación sobre el formato real de FL Studio.

No se ha usado el byte de formato interno `FLhd` como si fuera el número de versión de FL Studio. PyFLP documenta el evento de versión del productor como texto ASCII (evento 199 en este proyecto) y advierte que bajar esa cadena no hace que un proyecto cargue mágicamente. Véase: https://pyflp.readthedocs.io/en/stable/architecture/flp-format.html y https://github.com/demberto/PyFLP/blob/master/pyflp/project.py.

## Cómo auditar
```
python run_app.py audit-downgrade "proyecto.flp" --target 20
```
El comando no crea ni modifica archivos. Devuelve código de salida 4 cuando no existen reglas validadas.

## Cómo se activa una regla real
Cada regla debe registrar el ID observado, versiones de origen y destino, la razón de incompatibilidad, una fuente/evidencia, una fixture de origen identificada por SHA-256 y qué información se pierde. La marca `validated` debe reservarse para una regla comprobada con muestras representativas y apertura real en la versión de destino. Los hashes y pruebas no sustituyen la validación auditiva/manual.

## Estado de validación
- Pruebas unitarias sintéticas: ejecutables en CI/local.
- Proyectos FLP reales: no proporcionados en esta fase.
- Apertura y reproducción en FL Studio 20/12/11/9/8/7: pendiente.
- EXE/instalador: requiere compilación y prueba en Windows 10/11 x64.
