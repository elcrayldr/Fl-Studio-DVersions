"""Constantes del formato FLP.

CONFIRMADO (estructura de contenedor, ampliamente documentada por la comunidad):
  - Cabecera: 'FLhd' + u32 tamaño (normalmente 6) + formato(i16) + nº canales(u16) + PPQ(u16)
  - Datos:    'FLdt' + u32 tamaño + secuencia de eventos
  - Evento:   id(u8) + datos. id<64: 1 byte; 64-127: 2 bytes; 128-191: 4 bytes;
              192-255: longitud varint (7 bits, little-endian) + datos.

INFERIDO (significado de cada id): tomado de documentación comunitaria; NO verificado
contra proyectos reales de FL Studio en este entorno. Se etiqueta como 'inferido'.
"""
HEADER_MAGIC = b"FLhd"
DATA_MAGIC = b"FLdt"

# id -> clave semántica (eventos de texto)
TEXT_EVENTS: dict[int, str] = {
    192: "channel_name",
    193: "pattern_name",
    194: "title",
    195: "comment",
    196: "sample_path",
    197: "url",
    199: "fl_version",
    201: "default_plugin_name",
    202: "data_path",
    203: "plugin_name",
    206: "genre",
    207: "author",
}

# id -> clave semántica (eventos numéricos / blobs reconocidos solo por presencia)
OTHER_KNOWN_EVENTS: dict[int, str] = {
    64: "new_channel",       # WORD
    65: "new_pattern",       # WORD
    66: "tempo_legacy",      # WORD (bpm, formatos antiguos)
    156: "tempo",            # DWORD (bpm*1000)
    224: "pattern_notes",    # blob
    233: "playlist_items",   # blob
}

KNOWN_IDS = set(TEXT_EVENTS) | set(OTHER_KNOWN_EVENTS)

TEXT_UTF16_FROM_VERSION = (11, 5)   # inferido: FL >= 11.5 guarda texto en UTF-16LE
